package com.objectslocation;

import com.adidas.pages.AssignmentPage;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Steps;

public class PageReferences extends PageObject {

	@Steps


	public AssignmentPage assignment;

}
